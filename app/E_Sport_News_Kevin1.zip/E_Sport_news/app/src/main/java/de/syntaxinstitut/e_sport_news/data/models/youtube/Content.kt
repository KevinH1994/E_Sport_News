package de.syntaxinstitut.e_sport_news.data.models.youtube

import de.syntaxinstitut.e_sport_news.data.models.youtube.Video

data class Content(
    val video: Video
)