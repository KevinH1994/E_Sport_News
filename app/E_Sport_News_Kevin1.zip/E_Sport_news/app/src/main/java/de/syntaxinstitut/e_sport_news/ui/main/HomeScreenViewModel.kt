package de.syntaxinstitut.e_sport_news.ui.main

import android.app.Application
import androidx.lifecycle.AndroidViewModel

/**
 * Das ViewModel des One Fragments
 */
class HomeScreenViewModel(application: Application) : AndroidViewModel(application) {
}
