package de.syntaxinstitut.e_sport_news.data.models.news

class NewsList {
}