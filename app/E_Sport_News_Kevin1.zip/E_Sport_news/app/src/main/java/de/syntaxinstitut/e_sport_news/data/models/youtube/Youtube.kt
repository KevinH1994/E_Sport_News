package de.syntaxinstitut.e_sport_news.data.models.youtube

data class Youtube(
    val contents: List<Content>,

    )